function abrirBuscador() {
    var archivoInput = document.getElementById('archivoInput');
    archivoInput.click();
}

function mostrarNombreArchivo() {
    var archivoInput = document.getElementById('archivoInput');
    var nombreArchivo = document.getElementById('nombreArchivo');

    if (archivoInput.files.length > 0) {
        nombreArchivo.textContent = 'Archivo seleccionado: ' + archivoInput.files[0].name;
    } else {
        nombreArchivo.textContent = 'Ningún archivo seleccionado';
    }
}

// evento.js

// evento.js

function mostrarBuscarEstudiantes() {
    // Lógica para mostrar el contenido y ocultar otros elementos
    document.getElementById('buscador').style.display = 'block';
    document.getElementById('tablaContainer').style.display = 'block';
    document.getElementById('tablaContainerNueva').style.display = 'none';
    document.getElementById('comboBox1').style.display = 'none';
    document.getElementById('comboBox2').style.display = 'none';
    document.getElementById('comboBox3').style.display = 'none';
}

function mostrarContenidoAdicional() {
    // Lógica para mostrar el contenido adicional y ocultar otros elementos
    document.getElementById('tablaContainer').style.display = 'none';
    document.getElementById('buscador').style.display = 'none';
    document.getElementById('tablaContainerNueva').style.display = 'block';
    document.getElementById('comboBox1').style.display = 'block';
    document.getElementById('comboBox2').style.display = 'block';
    document.getElementById('comboBox3').style.display = 'block';
}

function ocultarBuscarEstudiantes() {
    // Lógica para ocultar el contenido adicional y mostrar otros elementos
    document.getElementById('tablaContainerNueva').style.display = 'none';
    document.getElementById('comboBox1').style.display = 'none';
    document.getElementById('comboBox2').style.display = 'none';
    document.getElementById('comboBox3').style.display = 'none';
}

function mostrarNombreArchivo() {
    // Lógica para mostrar el nombre del archivo
    const input = document.getElementById('archivoInput');
    const fileName = input.value.split('\\').pop();
    document.getElementById('nombreArchivo').innerText = 'Archivo cargado: ' + fileName;
}

