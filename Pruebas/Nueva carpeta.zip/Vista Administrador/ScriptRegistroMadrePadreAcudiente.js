document.addEventListener("DOMContentLoaded", function () {
    // Ocultar contenedor-buscar, contenedor-tabla, contenedor-combo, y contenedor-tabla-dos al cargar la página
    var contenedorInformacionPadre = document.querySelector(".contenedor-informacion-padre");
    var contenedorInformacionMadre = document.querySelector(".contenedor-informacion-madre");

    if (contenedorInformacionPadre) {
        contenedorInformacionPadre.style.display = "none";
        contenedorInformacionMadre.style.display = "none";
    }
});

document.addEventListener("DOMContentLoaded", function () {
    var botonModuloPadre = document.getElementById("boton-modulo-padre");
    var contenedorInformacionPadre = document.querySelector(".contenedor-informacion-padre");
    var contenedorInformacionMadre = document.querySelector(".contenedor-informacion-madre");

    botonModuloPadre.addEventListener("click", function () {
        if (contenedorInformacionPadre.style.display === "none") {
            contenedorInformacionPadre.style.display = "block";
            contenedorInformacionPadre.style.display = "flex";
        } else {
            contenedorInformacionMadre.style.display = "none";
        }
    });
});

document.addEventListener("DOMContentLoaded", function () {
    var botonModuloMadre = document.getElementById("boton-modulo-madre");
    var contenedorInformacionPadre = document.querySelector(".contenedor-informacion-padre");
    var contenedorInformacionMadre = document.querySelector(".contenedor-informacion-madre");

    botonModuloMadre.addEventListener("click", function () {
        if (contenedorInformacionPadre.style.display === "none") {
            contenedorInformacionMadre.style.display = "block";
            contenedorInformacionMadre.style.display = "flex";
        } else {
            contenedorInformacionPadre.style.display = "none";
        }
    });
});

            <button id="mostrarEstudiantes" class="boton-principal">Mostrar Estudiantes</button>
            <button id="buscar-estudiante" class="boton-principal">Buscar Estudiante</button>



